function Comp2() {
  return (
    <div className="justify-center border-x-20 border-y-12  border-opacity-100 border-red-600 flex-block px-1 py-1 stretch-1/2 justify-between-auto align-middle items-center">
      <h1 className='border-l col-span-2 justify-center'>TO DO List</h1>
      <input type="text" className=" flex-auto justify-center w-1/2 h-10 border-r-8 border-l-8 border-opactiy-100 rounded"/>
    </div>
  )
}
export default Comp2