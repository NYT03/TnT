import './Mynew.css'
function Mynew(){
    return (
        <h1 id='Hello'>Hello from component </h1>
    )
}
export default Mynew