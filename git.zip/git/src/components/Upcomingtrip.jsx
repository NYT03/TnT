// import axios from "axios";
// import { useEffect, useState } from "react";
// import Posts from "./Posts";

// function Upcomingtrip() {
// const[data,setData]=useState([]);
// const[Image,setImage]=useState([]);
//     const options = {
//       method: 'GET',
//       url: 'https://booking-com.p.rapidapi.com/v1/static/hotels',
//       params: {page: '0'},
//       headers: {
//         'X-RapidAPI-Key': '2d082ac7eamsh375e70446c751f4p180218jsn77252ad87a94',
//         'X-RapidAPI-Host': 'booking-com.p.rapidapi.com'
//       }
//     };

//     const options2 = {
//         method: 'GET',
//         url: 'https://booking-com.p.rapidapi.com/v1/hotels/photos',
//         params: {
//             hotel_id: '1377073',
//             locale: 'en-gb'
//     },
//     headers: {
//         'X-RapidAPI-Key': '2d082ac7eamsh375e70446c751f4p180218jsn77252ad87a94',
//       'X-RapidAPI-Host': 'booking-com.p.rapidapi.com'
//     }
//   };
  
//   useEffect(() => {
//       const response = axios.request(options);
//       const response2 =  axios.request(options2);
//       setData(response);
//       setImage(response2);
//   },[data,Image]);
  
//   return (
//   <div>
//     {data.map((item)=>{
//       return <Posts image={Image} rating={item.rating} discription={item.discription} address={item.address} key={data.}/>
//     })}
//   </div>
//   );
// }

// export default Upcomingtrip;
import React from 'react'

function Upcomingtrip() {
  return (
    <div>Upcomingtrip</div>
  )
}

export default Upcomingtrip