import HomeImages from "./HomeImages";
import ChangingText from "./ChangingText";
const imagePaths = [
  "./assets/Images2/IMG-20240413-WA0008.jpg",
  "./assets/Images2/IMG-20240413-WA0009.jpg",
  "./assets/Images2/IMG-20240413-WA0010.jpg",
];
const Home = () => {
  return (
    <div>
      <div >
        <img src="src\components\assets\images\Vector 2.png" alt="image" className="w-full absolute"/>
      </div>
      <div className=" flex flex-row space-x-3.5">
        <HomeImages imagePaths={imagePaths} />
        <ChangingText />
      </div>
      <div>
        <div className="m-5 relative grid grid-cols-2">
          <div className="m-5 shadow-2xl rounded px-5 md:px-5 bg-gray-100">
          <h1 className="ml-5 mt-2 text-5xl">OUR GOALS</h1>
          <p className="m-5 text-left text-lg">
          At our travel company, our mission is crystal clear: to make travel accessible and enjoyable for everyone, regardless of age or budget constraints. We are driven by the belief that memorable experiences shouldn &apos  t come with a hefty price tag. Our goal is to provide exceptional services at the most competitive prices in the industry. From providing comfortable lodging and delicious meals to ensuring refreshing bathing facilities, we prioritize the comfort and satisfaction of our travelers above all else. Additionally, as a token of appreciation for choosing us, we delight our customers with complimentary gifts, further enhancing their journey. Our dedicated team is committed to realizing this vision, ensuring that every traveler who embarks on a journey with us experiences the perfect blend of affordability, comfort, and unforgettable moments.
          </p>
          </div>
          <div >
          <HomeImages imagePaths={imagePaths} margin={"m-4"}/>
          </div>
        </div>
      </div>
      <img src="src\components\assets\images\Vector 3.png" className="w-full"/>
    </div>
  );
};
export default Home;