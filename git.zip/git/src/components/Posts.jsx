// import * as React from "react";

// function Posts({image,rating,discription,address}) {
//   return (
//     <div className="flex flex-col justify-center px-3.5 py-6 bg-white rounded-xl">
//       <div className="max-md:max-w-full">
//         <div className="flex gap-5 max-md:flex-col max-md:gap-0">
//           <div className="flex flex-col w-[41%] max-md:ml-0 max-md:w-full">
//             <img
//               loading="lazy"
//               src={image}
//               className="self-stretch my-auto w-full aspect-[1.39] max-md:mt-10 max-md:max-w-full"
//             />
//           </div>
//           <div className="flex flex-col ml-5 w-[59%] max-md:ml-0 max-md:w-full">
//             <div className="flex flex-col grow px-2.5 py-3 w-full rounded-2xl max-md:mt-6 max-md:max-w-full">
//               <div className="text-3xl text-center text-black max-md:max-w-full">
//                 Journey to Amarnath Cave Temple
//               </div>
//               <div className="mt-5 text-base font-bold text-white max-md:max-w-full">
//                 Discription:
//               </div>
//               <div className="text-base font-bold text-white max-md:max-w-full">
//                 city,address
//               </div>
//               <div className="flex gap-0 self-start mt-6">
//                 <div className="text-base font-bold text-white">Rating:</div>
//                 <div className="flex gap-1 my-auto">
//                   {/* //rating */}
//               </div>
//               <div className="mt-6 text-base font-bold text-white max-md:max-w-full">
//                 Address:
//               </div>
//               <div className="mt-2.5 text-base font-bold text-white max-md:max-w-full">
//                 {address}
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//     </div>
//     );
// }
// export default Posts;