import { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import './styles/HomeImages.css';
function HomeImages({ imagePaths,margin }) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % imagePaths.length);
    }, 4000);

    return () => clearInterval(intervalId);
  }, [imagePaths.length]);
  const getMarginStyles = () => {
    // Create a default margin style if no margin prop is provided
    let marginStyle = 'm-20'; // Adjust default margins as needed

    // Apply custom margin values from the prop (if any)
    if (margin) {
      marginStyle = margin; // Use the provided margin directly
    }

    return marginStyle;
  };
  // Assuming your images are stored in a static folder named 'images' within your project
  const baseUrl = 'src/components/'; // Adjust this path if necessary
  const images = imagePaths.map((imagePath) => `${baseUrl}${imagePath}`);

  return (
    <img src={images[currentIndex]} alt="Image Slider" className={`resize object-cover rounded-xl shadow-[_10px_10px_10px_rgba(0,0,0,0.4)] drop-shadow-xl max-w-2xl max-h-2xl ${getMarginStyles()}`}/>
  );
}

HomeImages.propTypes = {
  imagePaths: PropTypes.arrayOf(PropTypes.string).isRequired,
  margin: PropTypes.string,
};

export default HomeImages;
