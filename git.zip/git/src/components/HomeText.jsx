import React from 'react'
import './styles/HomeText.css';
function HomeText() {
  return (
    <div className="">
        <div className="property-1-=-default">
          <p className="text-1">Kailashnath Temple</p>
          <p className="text-2">Located in India, the Kailashnath Temple is a cave temple that is carved out of a single rock. It is dedicated to the god Shiva and is considered to be one of the most sacred Hindu temples in the world.
  </p>
        </div>
        <div className="property-1-=-variant-2">
          <p className="text-3">Angkor Wat</p>
          <p className="text-4">Located in Cambodia, Angkor Wat is the largest Hindu temple in the world. It was built in the 12th century by the Khmer Empire and is dedicated to the god Vishnu.
  
  </p>
        </div>
        <div className="property-1-=-variant-3">
          <p className="text-5">Prambanan Temple</p>
          <p className="text-6">Located in Indonesia, the Prambanan Temple is the largest Hindu temple complex in Indonesia. It was built in the 9th century by the Mataram Kingdom and is dedicated to the Trimurti (Brahma, Vishnu, and Shiva).</p>
        </div>
        <div className="property-1-=-variant-4">
          <p className="text-7">Brihadeeswarar Temple</p>
          <p className="text-8">Located in the southern Indian state of Tamil Nadu, the Brihadeeswarar Temple is an example of Chola Dynasty architecture. Dedicated to Lord Shiva, the temple is known for its towering vimana (tower) that is 216 feet tall. The temple complex is also home to a number of beautiful sculptures and murals.</p>
        </div>
        <div className="property-1-=-variant-5">
          <p className="text-9">Lingaraja Temple</p>
          <p className="text-1-0">Located in the eastern Indian state of Odisha, the Lingaraja Temple is a UNESCO World Heritage Site. Dedicated to Lord Shiva, the temple is built in the Kalinga architectural style. The temple complex is spread over 5 acres and is home to a number of smaller shrines and monuments.</p>
        </div>
      </div>
 
  )
}

export default HomeText;